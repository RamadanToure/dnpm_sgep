<?php $__env->startSection('content'); ?>
<h1 class="h3 mt-5 mb-4 text-gray-800">Analyse des Étapes de la Procédure</h1>

<div class="row">
    <div class="col-lg-12">
        <!-- Basic Card Example -->
        <div class="card shadow mb-4">

            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-header-blue">
                        <tr>
                            <th scope="col">Étape</th>
                            <th scope="col">Durée moyenne (jours)</th>
                            <th scope="col">Statut actuel</th>
                            <th scope="col">Étapes en retard (jours)</th>
                            <th scope="col">Taux de réussite (%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dureesMoyennes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape => $duree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($etape); ?></td>
                                <td><?php echo e($duree); ?></td>
                                <td><?php echo e(isset($statuts[$etape]) ? $statuts[$etape] : 'Non défini'); ?></td>
                                <td><?php echo e(isset($retards[$etape]) ? $retards[$etape] : 'Non défini'); ?></td>
                                <td>
                                    <?php if(!is_string($duree)): ?>
                                        <?php
                                            $tauxReussite = ($duree / $nombreTotalEtapes) * 100;
                                        ?>
                                        <?php echo e($tauxReussite); ?>%
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\Mes Applications\dnpm_sgep\resources\views/admin/demande/etapes.blade.php ENDPATH**/ ?>