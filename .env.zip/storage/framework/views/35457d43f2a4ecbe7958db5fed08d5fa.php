<?php $__env->startSection('content'); ?>
    <h1 class="h3 mt-5 mb-4 text-gray-800">Liste des utilisateurs</h1>
    <div class="row">
        <div class="col-lg-12">
            <!-- Basic Card Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <a href="<?php echo e(route('users.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                        <i class="fas fa-plus fa-sm text-white-50"></i> Nouvel utilisateur
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div><br />
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Utilisateur</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($users->count() > 0): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <?php if($user->hasRole('admin')): ?>
                                                    <div class="badge badge-info">Administrateur</div>
                                                <?php else: ?>
                                                    <div class="badge badge-warning">Sous Administrateur</div>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary btn-circle btn-sm">
                                                    <i class="far fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" style="display: inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger btn-circle btn-sm" type="submit" onclick="return confirm('Voulez-vous vraiment supprimer cet enregistrement ?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td align="center" colspan="5">
                                            <h6>AUCUN ENREGISTREMENT TROUVÉ</h6>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\Mes Applications\dnpm_sgep\resources\views/admin/users/index.blade.php ENDPATH**/ ?>