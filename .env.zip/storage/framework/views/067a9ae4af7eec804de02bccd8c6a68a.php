<?php $__env->startSection('content'); ?>
    <h1 class="h3 mt-5 mb-4 text-gray-800">Modifier l'utilisateur</h1>
    <div class="row">
        <div class="col-lg-12">
            <!-- Basic Card Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Tous les champs marqués d'un * sont obligatoires</h6>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Nom d'utilisateur *</label>
                            <div class="col-sm-6">
                                <input id="name" name="name" type="text" class="form-control" placeholder="Nom d'utilisateur *" required value="<?php echo e($user->name); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-sm-2 col-form-label">Email *</label>
                            <div class="col-sm-6">
                                <input id="email" name="email" type="email" class="form-control" placeholder="email *" required value="<?php echo e($user->email); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="role" class="col-sm-2 col-form-label">Type d'utilisateur</label>
                            <div class="col-sm-6">
                                <select id="role" name="role" class="form-control" required>
                                    <?php if($user->type_user == 1): ?>
                                        <option value="1" selected>Administrateur</option>
                                        <option value="0">Sous administrateur</option>
                                    <?php else: ?>
                                        <option value="1">Administrateur</option>
                                        <option value="0" selected>Sous administrateur</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary btn-user"><i class="fa fa-save"></i> Modifier</button>
                            <a class="btn btn-danger btn-user" href="<?php echo e(route('users.index')); ?>"><i class="fa fa-times-circle"></i> Annuler</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Documents\Mes Applications\dnpm_sgep\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>